import clientPromise from "@/lib/mongodb";

export async function POST(request) {
  try {
    const body = await request.json();
    const { matricule, password } = body;

    if (!matricule || !password) {
      return new Response(
        JSON.stringify({ message: "Veuillez remplir tous les champs." }),
        { status: 400 }
      );
    }

    const client = await clientPromise;
    const db = client.db(process.env.MONGODB_DB);

    const user = await db
      .collection("users")
      .findOne({ matricule, password });

    if (user) {
      return new Response(
        JSON.stringify({ message: "Connexion réussie !" }),
        { status: 200 }
      );
    } else {
      return new Response(
        JSON.stringify({ message: "Matricule ou mot de passe incorrect." }),
        { status: 401 }
      );
    }
  } catch (error) {
    console.error("Erreur connexion :", error);
    return new Response(
      JSON.stringify({ message: "Erreur serveur lors de la connexion." }),
      { status: 500 }
    );
  }
}
