import clientPromise from "@/lib/mongodb";

export async function POST(request) {
  try {
    const body = await request.json();
    const { matricule, mail, nom, prenom, password } = body;

    if (!matricule || !mail || !nom || !prenom || !password) {
      return new Response(
        JSON.stringify({ message: "Tous les champs sont obligatoires." }),
        { status: 400 }
      );
    }

    const client = await clientPromise;
    const db = client.db(process.env.MONGODB_DB);

    const existingUser = await db
      .collection("users")
      .findOne({ $or: [{ matricule }, { mail }] });

    if (existingUser) {
      return new Response(
        JSON.stringify({ message: "Matricule ou email déjà utilisé." }),
        { status: 409 }
      );
    }

    await db.collection("users").insertOne({
      matricule,
      mail,
      nom,
      prenom,
      password, // Note : Pour la prod, il faut hasher le mot de passe !
    });

    return new Response(
      JSON.stringify({ message: "Inscription réussie !" }),
      { status: 201 }
    );
  } catch (error) {
    console.error("Erreur inscription :", error);
    return new Response(
      JSON.stringify({ message: "Erreur serveur lors de l'inscription." }),
      { status: 500 }
    );
  }
}
